# TaskFlow — MERN Task Manager

A production-style task management app built with **MongoDB, Express, React and Node.js**. Users can register, sign in, and manage tasks in a list or a drag-and-drop Kanban board, with dashboard analytics, due-date reminders, search, filters, pagination and dark mode.

## Features

- **Auth:** register/login with bcrypt-hashed passwords and JWT; protected routes; logout; friendly validation and error messages
- **Dashboard:** greeting, task counts, completion %, status donut, priority bars, 7-day activity chart, due-soon list, recent tasks
- **Tasks:** create, view, edit, delete, mark complete, change status; title, description, status, priority, due date, created/updated dates
- **Board view:** drag cards between columns (changes status) or within a column (reorders); order is saved to the API
- **Search & filters:** debounced search over title and description with match highlighting; filter by status, priority, due date (overdue / today / next 7 days / none); sort; state kept in the URL
- **Pagination** with a compact page window
- **Reminders:** bell menu with overdue and due-in-3-days tasks, refreshed automatically; one overdue nudge per session
- **Profile settings:** update name/email, change password, choose theme, delete account
- **UX:** dark/light mode (saved, no flash), skeleton loaders, empty and error states, toasts, confirmation modals, route fade transition, keyboard-accessible controls, responsive sidebar → mobile drawer

## Tech stack

React 18 (Vite), Tailwind CSS 3, React Router 6, Axios, Recharts, dnd-kit, react-hot-toast, lucide-react · Node.js, Express 4, Mongoose 8, JWT, bcryptjs, helmet, express-rate-limit

## Project structure

```
taskflow/
├── backend/
│   ├── config/db.js            # MongoDB connection (env-based)
│   ├── controllers/            # auth, task, user logic
│   ├── middleware/             # JWT protect, error handling
│   ├── models/                 # User, Task
│   ├── routes/                 # auth, tasks, users
│   ├── utils/httpError.js
│   ├── seed.js                 # optional demo data
│   ├── server.js
│   └── .env.example
└── frontend/
    ├── src/
    │   ├── components/         # UI pieces (+ charts/)
    │   ├── context/            # Auth + Theme providers
    │   ├── hooks/
    │   ├── layouts/            # AppLayout (sidebar), AuthLayout
    │   ├── pages/
    │   ├── services/api.js     # axios instance + API wrappers
    │   ├── utils/date.js
    │   ├── App.jsx
    │   └── main.jsx
    └── .env.example
```

## Setup

**Prerequisites:** Node.js 18+, and MongoDB running locally *or* a free [MongoDB Atlas](https://www.mongodb.com/atlas) cluster.

### 1. Backend

```bash
cd backend
npm install
cp .env.example .env        # then edit .env
npm run dev                 # http://localhost:5000
```

`.env` values:

| Variable | Description |
| --- | --- |
| `PORT` | API port (default 5000) |
| `MONGO_URI` | e.g. `mongodb://127.0.0.1:27017/taskflow` or your Atlas URI |
| `JWT_SECRET` | Long random string (`node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`) |
| `JWT_EXPIRES_IN` | Token lifetime, default `7d` |
| `CLIENT_URL` | Frontend origin allowed by CORS, default `http://localhost:5173` |

Optional demo data: `npm run seed` creates **demo@taskflow.dev / Demo@1234** with sample tasks.

### 2. Frontend

```bash
cd frontend
npm install
npm run dev                 # http://localhost:5173
```

In development Vite proxies `/api` to `http://localhost:5000`, so no extra config is needed. If the API is on another domain, set `VITE_API_URL` (see `frontend/.env.example`).

### 3. Production build

```bash
cd frontend && npm run build
cd ../backend && NODE_ENV=production npm start   # serves the API and frontend/dist together
```

## API documentation

Base URL: `/api`. Send `Authorization: Bearer <token>` on every endpoint except register and login. All responses are JSON with `success`; errors return `{ success: false, message, errors? }`.

### Auth

| Method | Endpoint | Body | Notes |
| --- | --- | --- | --- |
| POST | `/auth/register` | `name, email, password (min 8)` | 201 → `{ token, user }`; 409 if email exists |
| POST | `/auth/login` | `email, password` | → `{ token, user }`; 401 on invalid credentials |
| GET | `/auth/me` | — | Current user |

### Tasks

| Method | Endpoint | Description |
| --- | --- | --- |
| GET | `/tasks` | List your tasks. Query: `status`, `priority`, `search`, `due` (`overdue`\|`today`\|`week`\|`none`), `sort` (`createdAt`\|`updatedAt`\|`dueDate`\|`title`\|`order` + `:asc`/`:desc`), `page`, `limit` (max 200). → `{ tasks, pagination: { page, limit, total, pages } }` |
| POST | `/tasks` | Create. Body: `title` (required), `description`, `status`, `priority`, `dueDate` |
| GET | `/tasks/:id` | Task details |
| PUT | `/tasks/:id` | Update any subset of the create fields |
| DELETE | `/tasks/:id` | Delete |
| GET | `/tasks/stats` | Dashboard data: counts, completion %, status/priority distribution, 7-day activity, recent tasks, reminders |
| GET | `/tasks/reminders` | `{ overdue, overdueCount, dueSoon }` |
| PATCH | `/tasks/reorder` | Body `{ items: [{ id, status, order }] }` — persists drag-and-drop |

Task shape: `{ _id, title, description, status: "Pending"|"In Progress"|"Completed", priority: "Low"|"Medium"|"High", dueDate, completedAt, order, user, createdAt, updatedAt }`

### Users

| Method | Endpoint | Body |
| --- | --- | --- |
| PUT | `/users/profile` | `name?`, `email?` |
| PUT | `/users/password` | `currentPassword, newPassword` |
| DELETE | `/users/me` | `password` — deletes the account and all its tasks |

### Status codes

`400` validation / invalid ID · `401` missing or invalid token / bad credentials · `404` task not found (also returned for other users' tasks) · `409` duplicate email · `429` too many auth attempts · `500` server error (generic message, details only in server logs)

## Security notes

- Passwords hashed with bcrypt (12 rounds) and never returned by the API (`select: false` plus JSON transform)
- Every task query is scoped to `req.user._id`, so users cannot read or modify each other's tasks
- Request bodies are validated and whitelisted; search input is regex-escaped; helmet, CORS allow-list and login rate limiting are enabled
- The JWT is kept in `localStorage` for simplicity. For stricter setups, move it to an httpOnly, SameSite cookie

## Ideas to extend

Subtasks and labels, recurring tasks, email reminders (node-cron + nodemailer), refresh tokens, unit and integration tests (Jest + Supertest), Docker Compose, CI.
