const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { HttpError, asyncHandler } = require('../utils/httpError');

const EMAIL_RE = /^\S+@\S+\.\S+$/;

const signToken = (id) =>
  jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });

exports.register = asyncHandler(async (req, res) => {
  const { name, email, password } = req.body;
  const errors = [];
  if (!name || !String(name).trim()) errors.push('Name is required.');
  if (!email || !EMAIL_RE.test(String(email))) errors.push('A valid email is required.');
  if (!password || String(password).length < 8) errors.push('Password must be at least 8 characters.');
  if (errors.length) throw new HttpError(400, errors[0], errors);

  const exists = await User.findOne({ email: String(email).toLowerCase().trim() });
  if (exists) throw new HttpError(409, 'An account with this email already exists.');

  const user = await User.create({ name: String(name).trim(), email, password: String(password) });
  res.status(201).json({ success: true, token: signToken(user.id), user });
});

exports.login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) throw new HttpError(400, 'Email and password are required.');

  const user = await User.findOne({ email: String(email).toLowerCase().trim() }).select('+password');
  if (!user || !(await user.comparePassword(String(password)))) {
    throw new HttpError(401, 'Invalid email or password.');
  }
  res.json({ success: true, token: signToken(user.id), user });
});

exports.me = asyncHandler(async (req, res) => {
  res.json({ success: true, user: req.user });
});
