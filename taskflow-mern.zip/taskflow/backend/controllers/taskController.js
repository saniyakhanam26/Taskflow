const mongoose = require('mongoose');
const Task = require('../models/Task');
const { HttpError, asyncHandler } = require('../utils/httpError');

const STATUSES = ['Pending', 'In Progress', 'Completed'];
const PRIORITIES = ['Low', 'Medium', 'High'];
const SORT_FIELDS = ['createdAt', 'updatedAt', 'dueDate', 'title', 'order'];
const DAY = 864e5;

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// "Today" as a UTC-midnight Date. The client sends its local date (YYYY-MM-DD).
function todayStart(q) {
  if (/^\d{4}-\d{2}-\d{2}$/.test(q || '')) {
    const d = new Date(q);
    if (!isNaN(d)) return d;
  }
  const n = new Date();
  return new Date(Date.UTC(n.getUTCFullYear(), n.getUTCMonth(), n.getUTCDate()));
}

function safeTz(tz) {
  try {
    new Date().toLocaleDateString('en-US', { timeZone: tz });
    return tz;
  } catch {
    return 'UTC';
  }
}

// Validates + whitelists task fields from the request body
function parseInput(body, partial = false) {
  const data = {};
  const errors = [];

  if (!partial || body.title !== undefined) {
    const t = typeof body.title === 'string' ? body.title.trim() : '';
    if (!t) errors.push('Title is required.');
    else if (t.length > 120) errors.push('Title cannot exceed 120 characters.');
    else data.title = t;
  }
  if (body.description !== undefined) {
    const d = typeof body.description === 'string' ? body.description.trim() : '';
    if (d.length > 2000) errors.push('Description cannot exceed 2000 characters.');
    else data.description = d;
  }
  if (body.status !== undefined) {
    if (!STATUSES.includes(body.status)) errors.push('Status must be Pending, In Progress or Completed.');
    else data.status = body.status;
  }
  if (body.priority !== undefined) {
    if (!PRIORITIES.includes(body.priority)) errors.push('Priority must be Low, Medium or High.');
    else data.priority = body.priority;
  }
  if (body.dueDate !== undefined) {
    if (body.dueDate === null || body.dueDate === '') data.dueDate = null;
    else {
      const d = new Date(body.dueDate);
      if (isNaN(d)) errors.push('Due date is not a valid date.');
      else {
        d.setUTCHours(0, 0, 0, 0);
        data.dueDate = d;
      }
    }
  }
  if (errors.length) throw new HttpError(400, errors[0], errors);
  return data;
}

async function reminderLists(userId, t0) {
  const open = { user: userId, status: { $ne: 'Completed' } };
  const [overdue, overdueCount, dueSoon] = await Promise.all([
    Task.find({ ...open, dueDate: { $lt: t0 } }).sort({ dueDate: 1 }).limit(10),
    Task.countDocuments({ ...open, dueDate: { $lt: t0 } }),
    Task.find({ ...open, dueDate: { $gte: t0, $lt: new Date(+t0 + 3 * DAY) } }).sort({ dueDate: 1 }).limit(10),
  ]);
  return { overdue, overdueCount, dueSoon };
}

// GET /api/tasks?status&priority&search&due&sort&page&limit
exports.getTasks = asyncHandler(async (req, res) => {
  const { status, priority, search, due } = req.query;
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 10, 1), 200);
  const filter = { user: req.user._id };

  if (status) {
    if (!STATUSES.includes(status)) throw new HttpError(400, 'Invalid status filter.');
    filter.status = status;
  }
  if (priority) {
    if (!PRIORITIES.includes(priority)) throw new HttpError(400, 'Invalid priority filter.');
    filter.priority = priority;
  }
  if (search && String(search).trim()) {
    const rx = new RegExp(escapeRegex(String(search).trim().slice(0, 100)), 'i');
    filter.$or = [{ title: rx }, { description: rx }];
  }

  const t0 = todayStart(req.query.today);
  if (due === 'overdue') {
    filter.dueDate = { $lt: t0 };
    if (!filter.status) filter.status = { $ne: 'Completed' };
  } else if (due === 'today') filter.dueDate = { $gte: t0, $lt: new Date(+t0 + DAY) };
  else if (due === 'week') filter.dueDate = { $gte: t0, $lt: new Date(+t0 + 7 * DAY) };
  else if (due === 'none') filter.dueDate = null;

  const [field = 'createdAt', dir = 'desc'] = String(req.query.sort || 'createdAt:desc').split(':');
  if (!SORT_FIELDS.includes(field)) throw new HttpError(400, 'Invalid sort field.');
  const direction = dir === 'asc' ? 1 : -1;

  const total = await Task.countDocuments(filter);
  let tasks;
  if (field === 'dueDate') {
    // keep tasks without a due date at the end regardless of direction
    tasks = await Task.aggregate([
      { $match: filter },
      { $addFields: { _noDue: { $cond: [{ $eq: [{ $type: '$dueDate' }, 'date'] }, 0, 1] } } },
      { $sort: { _noDue: 1, dueDate: direction, createdAt: -1 } },
      { $skip: (page - 1) * limit },
      { $limit: limit },
      { $project: { _noDue: 0, __v: 0 } },
    ]);
  } else {
    tasks = await Task.find(filter)
      .sort({ [field]: direction, _id: 1 })
      .skip((page - 1) * limit)
      .limit(limit);
  }

  res.json({
    success: true,
    tasks,
    pagination: { page, limit, total, pages: Math.max(Math.ceil(total / limit), 1) },
  });
});

// GET /api/tasks/stats
exports.getStats = asyncHandler(async (req, res) => {
  const uid = req.user._id;
  const t0 = todayStart(req.query.today);
  const tz = safeTz(req.query.tz || 'UTC');
  const since = new Date(+t0 - 7 * DAY);
  const dayFmt = (field) => ({ $dateToString: { format: '%Y-%m-%d', date: field, timezone: tz } });

  const [byStatus, byPriority, recent, created, completed, reminders] = await Promise.all([
    Task.aggregate([{ $match: { user: uid } }, { $group: { _id: '$status', count: { $sum: 1 } } }]),
    Task.aggregate([{ $match: { user: uid } }, { $group: { _id: '$priority', count: { $sum: 1 } } }]),
    Task.find({ user: uid }).sort({ createdAt: -1 }).limit(5),
    Task.aggregate([{ $match: { user: uid, createdAt: { $gte: since } } }, { $group: { _id: dayFmt('$createdAt'), count: { $sum: 1 } } }]),
    Task.aggregate([{ $match: { user: uid, completedAt: { $gte: since } } }, { $group: { _id: dayFmt('$completedAt'), count: { $sum: 1 } } }]),
    reminderLists(uid, t0),
  ]);

  const sm = Object.fromEntries(byStatus.map((s) => [s._id, s.count]));
  const pm = Object.fromEntries(byPriority.map((p) => [p._id, p.count]));
  const cm = Object.fromEntries(created.map((c) => [c._id, c.count]));
  const dm = Object.fromEntries(completed.map((c) => [c._id, c.count]));
  const total = STATUSES.reduce((n, s) => n + (sm[s] || 0), 0);

  const activity = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(+t0 - i * DAY);
    const key = d.toISOString().slice(0, 10);
    activity.push({
      date: key,
      day: d.toLocaleDateString('en-US', { weekday: 'short', timeZone: 'UTC' }),
      created: cm[key] || 0,
      completed: dm[key] || 0,
    });
  }

  res.json({
    success: true,
    stats: {
      total,
      pending: sm.Pending || 0,
      inProgress: sm['In Progress'] || 0,
      completed: sm.Completed || 0,
      completionRate: total ? Math.round(((sm.Completed || 0) / total) * 100) : 0,
      byStatus: STATUSES.map((s) => ({ name: s, count: sm[s] || 0 })),
      byPriority: PRIORITIES.map((p) => ({ name: p, count: pm[p] || 0 })),
      activity,
      recent,
      reminders,
    },
  });
});

// GET /api/tasks/reminders
exports.getReminders = asyncHandler(async (req, res) => {
  const lists = await reminderLists(req.user._id, todayStart(req.query.today));
  res.json({ success: true, ...lists });
});

exports.getTask = asyncHandler(async (req, res) => {
  const task = await Task.findOne({ _id: req.params.id, user: req.user._id });
  if (!task) throw new HttpError(404, 'Task not found.');
  res.json({ success: true, task });
});

exports.createTask = asyncHandler(async (req, res) => {
  const data = parseInput(req.body);
  if (data.status === 'Completed') data.completedAt = new Date();
  const task = await Task.create({ ...data, order: Date.now(), user: req.user._id });
  res.status(201).json({ success: true, task });
});

exports.updateTask = asyncHandler(async (req, res) => {
  const task = await Task.findOne({ _id: req.params.id, user: req.user._id });
  if (!task) throw new HttpError(404, 'Task not found.');

  const data = parseInput(req.body, true);
  if (data.status && data.status !== task.status) {
    data.completedAt = data.status === 'Completed' ? new Date() : null;
    data.order = Date.now(); // land at the bottom of the new column
  }
  task.set(data);
  await task.save();
  res.json({ success: true, task });
});

exports.deleteTask = asyncHandler(async (req, res) => {
  const task = await Task.findOneAndDelete({ _id: req.params.id, user: req.user._id });
  if (!task) throw new HttpError(404, 'Task not found.');
  res.json({ success: true, message: 'Task deleted.' });
});

// PATCH /api/tasks/reorder  { items: [{ id, status, order }] }
exports.reorderTasks = asyncHandler(async (req, res) => {
  const { items } = req.body;
  if (!Array.isArray(items) || !items.length || items.length > 500) {
    throw new HttpError(400, 'items must be a non-empty array (max 500).');
  }
  for (const it of items) {
    if (!mongoose.isValidObjectId(it.id) || !STATUSES.includes(it.status) || !Number.isFinite(it.order)) {
      throw new HttpError(400, 'Invalid reorder payload.');
    }
  }

  const existing = await Task.find({ _id: { $in: items.map((i) => i.id) }, user: req.user._id }).select('status completedAt');
  const byId = new Map(existing.map((t) => [t.id, t]));
  const now = new Date();

  const ops = items
    .filter((i) => byId.has(i.id))
    .map((i) => {
      const t = byId.get(i.id);
      const set = { status: i.status, order: i.order };
      if (i.status === 'Completed') {
        if (!t.completedAt) set.completedAt = now;
      } else set.completedAt = null;
      return {
        updateOne: {
          filter: { _id: i.id, user: req.user._id },
          update: { $set: set },
          timestamps: t.status !== i.status, // only bump updatedAt when the status changed
        },
      };
    });

  if (ops.length) await Task.bulkWrite(ops);
  res.json({ success: true, updated: ops.length });
});
