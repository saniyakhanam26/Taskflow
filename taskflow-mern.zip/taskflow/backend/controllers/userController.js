const User = require('../models/User');
const Task = require('../models/Task');
const { HttpError, asyncHandler } = require('../utils/httpError');

const EMAIL_RE = /^\S+@\S+\.\S+$/;

exports.updateProfile = asyncHandler(async (req, res) => {
  const { name, email } = req.body;
  if (name !== undefined) {
    if (!String(name).trim()) throw new HttpError(400, 'Name cannot be empty.');
    req.user.name = String(name).trim();
  }
  if (email !== undefined) {
    const next = String(email).toLowerCase().trim();
    if (!EMAIL_RE.test(next)) throw new HttpError(400, 'Please enter a valid email address.');
    if (next !== req.user.email) {
      const taken = await User.findOne({ email: next });
      if (taken) throw new HttpError(409, 'That email is already in use.');
      req.user.email = next;
    }
  }
  await req.user.save();
  res.json({ success: true, user: req.user });
});

exports.changePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  if (!currentPassword || !newPassword) throw new HttpError(400, 'Current and new password are required.');
  if (String(newPassword).length < 8) throw new HttpError(400, 'New password must be at least 8 characters.');

  const user = await User.findById(req.user.id).select('+password');
  if (!(await user.comparePassword(String(currentPassword)))) {
    throw new HttpError(400, 'Current password is incorrect.');
  }
  if (currentPassword === newPassword) throw new HttpError(400, 'New password must differ from the current one.');

  user.password = String(newPassword);
  await user.save();
  res.json({ success: true, message: 'Password updated.' });
});

exports.deleteAccount = asyncHandler(async (req, res) => {
  const { password } = req.body;
  if (!password) throw new HttpError(400, 'Password is required to delete your account.');

  const user = await User.findById(req.user.id).select('+password');
  if (!(await user.comparePassword(String(password)))) throw new HttpError(400, 'Password is incorrect.');

  await Task.deleteMany({ user: user._id });
  await user.deleteOne();
  res.json({ success: true, message: 'Account deleted.' });
});
