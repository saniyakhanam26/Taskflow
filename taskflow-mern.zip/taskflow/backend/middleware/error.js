const { HttpError } = require('../utils/httpError');

exports.notFound = (req, res, next) =>
  next(new HttpError(404, `Route not found: ${req.method} ${req.originalUrl}`));

// eslint-disable-next-line no-unused-vars
exports.errorHandler = (err, req, res, next) => {
  let status = err.status || 500;
  let message = err.message;
  let errors = err.errors;

  if (err.name === 'CastError') {
    status = 400;
    message = 'Invalid ID format.';
  } else if (err.name === 'ValidationError') {
    status = 400;
    errors = Object.values(err.errors).map((e) => e.message);
    message = errors[0];
  } else if (err.code === 11000) {
    status = 409;
    message = 'An account with this email already exists.';
  } else if (err.type === 'entity.parse.failed') {
    status = 400;
    message = 'Malformed JSON in request body.';
  }

  if (status >= 500) {
    console.error(err);
    if (!(err instanceof HttpError)) message = 'Something went wrong on our side. Please try again.';
  }

  res.status(status).json({ success: false, message, ...(errors && { errors }) });
};
