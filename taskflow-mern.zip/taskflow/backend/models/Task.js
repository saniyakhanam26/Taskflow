const mongoose = require('mongoose');

const taskSchema = new mongoose.Schema(
  {
    title: { type: String, required: [true, 'Title is required.'], trim: true, maxlength: [120, 'Title cannot exceed 120 characters.'] },
    description: { type: String, trim: true, default: '', maxlength: [2000, 'Description cannot exceed 2000 characters.'] },
    status: { type: String, enum: ['Pending', 'In Progress', 'Completed'], default: 'Pending' },
    priority: { type: String, enum: ['Low', 'Medium', 'High'], default: 'Medium' },
    dueDate: { type: Date, default: null },
    completedAt: { type: Date, default: null },
    // Position inside a board column (used by drag-and-drop)
    order: { type: Number, default: () => Date.now() },
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  },
  { timestamps: true } // adds createdAt + updatedAt
);

taskSchema.index({ user: 1, status: 1, order: 1 });
taskSchema.index({ user: 1, dueDate: 1 });

taskSchema.set('toJSON', {
  transform: (_doc, ret) => {
    delete ret.__v;
    return ret;
  },
});

module.exports = mongoose.model('Task', taskSchema);
