const router = require('express').Router();
const c = require('../controllers/taskController');
const { protect } = require('../middleware/auth');

router.use(protect);

router.route('/').get(c.getTasks).post(c.createTask);
router.get('/stats', c.getStats);
router.get('/reminders', c.getReminders);
router.patch('/reorder', c.reorderTasks);
router.route('/:id').get(c.getTask).put(c.updateTask).delete(c.deleteTask);

module.exports = router;
