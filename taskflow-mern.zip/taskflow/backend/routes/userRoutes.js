const router = require('express').Router();
const { updateProfile, changePassword, deleteAccount } = require('../controllers/userController');
const { protect } = require('../middleware/auth');

router.use(protect);

router.put('/profile', updateProfile);
router.put('/password', changePassword);
router.delete('/me', deleteAccount);

module.exports = router;
