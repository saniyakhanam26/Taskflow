// Creates a demo account with sample tasks (handy for screenshots / demos).
// Usage: npm run seed   →  demo@taskflow.dev / Demo@1234
require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');
const Task = require('./models/Task');

const day = (n) => {
  const d = new Date();
  d.setUTCHours(0, 0, 0, 0);
  d.setUTCDate(d.getUTCDate() + n);
  return d;
};

const samples = [
  ['Finalize project report', 'Proofread chapters 3–5 and add the conclusion.', 'In Progress', 'High', 1],
  ['Prepare demo presentation', 'Slides for the viva. Include architecture diagram.', 'Pending', 'High', 3],
  ['Fix login validation bug', 'Show inline error when the email is malformed.', 'Completed', 'Medium', -2],
  ['Review pull requests', 'Two open PRs waiting for review.', 'Pending', 'Medium', -1],
  ['Set up CI pipeline', 'Run lint and tests on every push.', 'In Progress', 'Medium', 5],
  ['Write API documentation', 'Document all endpoints in the README.', 'Completed', 'Low', -4],
  ['Design database indexes', 'Add compound indexes for the tasks collection.', 'Completed', 'Medium', -6],
  ['Plan next sprint', 'Pick the top priorities for next week.', 'Pending', 'Low', 7],
  ['Deploy to production', 'Backend on Render, frontend on Vercel.', 'Pending', 'High', 10],
  ['Refactor task controller', 'Split validation from business logic.', 'In Progress', 'Low', 2],
];

(async () => {
  await mongoose.connect(process.env.MONGO_URI);
  await User.deleteOne({ email: 'demo@taskflow.dev' });
  const user = await User.create({ name: 'Demo User', email: 'demo@taskflow.dev', password: 'Demo@1234' });
  await Task.insertMany(
    samples.map(([title, description, status, priority, due], i) => ({
      title, description, status, priority, dueDate: day(due), user: user._id, order: i,
      completedAt: status === 'Completed' ? day(due) : null,
      createdAt: day(-7 + (i % 6)),
    }))
  );
  console.log('Seeded demo@taskflow.dev / Demo@1234');
  await mongoose.disconnect();
})();
