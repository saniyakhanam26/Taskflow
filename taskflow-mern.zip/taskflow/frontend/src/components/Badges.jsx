import { Calendar, Flag } from 'lucide-react';
import { dueInfo } from '../utils/date.js';

export const STATUSES = ['Pending', 'In Progress', 'Completed'];
export const PRIORITIES = ['Low', 'Medium', 'High'];

const statusStyle = {
  Pending: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300',
  'In Progress': 'bg-indigo-50 text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-300',
  Completed: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300',
};
const statusDot = { Pending: 'bg-slate-400', 'In Progress': 'bg-indigo-500', Completed: 'bg-emerald-500' };

export const priorityText = {
  Low: 'text-slate-500 dark:text-slate-400',
  Medium: 'text-amber-600 dark:text-amber-400',
  High: 'text-red-600 dark:text-red-400',
};
export const priorityBorder = {
  Low: 'border-l-slate-300 dark:border-l-slate-600',
  Medium: 'border-l-amber-400',
  High: 'border-l-red-500',
};

export function StatusBadge({ status }) {
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium ${statusStyle[status]}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${statusDot[status]}`} />
      {status}
    </span>
  );
}

export function PriorityBadge({ priority }) {
  return (
    <span className={`inline-flex items-center gap-1 text-xs font-medium ${priorityText[priority]}`}>
      <Flag className="h-3.5 w-3.5" />
      {priority}
    </span>
  );
}

const dueTone = {
  overdue: 'text-red-600 dark:text-red-400',
  soon: 'text-amber-600 dark:text-amber-400',
  normal: 'text-slate-500 dark:text-slate-400',
};

export function DueLabel({ task }) {
  const info = dueInfo(task);
  if (!info) return null;
  return (
    <span className={`inline-flex items-center gap-1 text-xs font-medium ${dueTone[info.tone]}`}>
      <Calendar className="h-3.5 w-3.5" />
      {info.label}
    </span>
  );
}
