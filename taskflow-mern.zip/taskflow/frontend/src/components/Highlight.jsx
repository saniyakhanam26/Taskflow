const escape = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// Wraps matches of `query` in <mark> (used by search)
export default function Highlight({ text, query }) {
  const q = query?.trim();
  if (!q) return text;
  const parts = text.split(new RegExp(`(${escape(q)})`, 'ig'));
  return parts.map((p, i) =>
    p.toLowerCase() === q.toLowerCase() ? (
      <mark key={i} className="rounded bg-amber-200/70 px-0.5 text-inherit dark:bg-amber-400/30">{p}</mark>
    ) : (
      <span key={i}>{p}</span>
    )
  );
}
