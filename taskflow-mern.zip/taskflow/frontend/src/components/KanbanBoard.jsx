import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  DndContext, DragOverlay, KeyboardSensor, MouseSensor, TouchSensor,
  closestCorners, useDroppable, useSensor, useSensors,
} from '@dnd-kit/core';
import { SortableContext, arrayMove, sortableKeyboardCoordinates, useSortable, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { GripVertical, Plus, Pencil, Trash2 } from 'lucide-react';
import { PriorityBadge, DueLabel, STATUSES, priorityBorder } from './Badges.jsx';

const byOrder = (a, b) => a.order - b.order;

function CardBody({ task, onDelete, overlay }) {
  return (
    <div className={`card border-l-[3px] p-3 ${priorityBorder[task.priority]} ${overlay ? 'shadow-lg' : 'hover:shadow-md dark:hover:shadow-none'}`}>
      <div className="flex items-start gap-2">
        <GripVertical className="mt-0.5 h-4 w-4 shrink-0 cursor-grab text-slate-300 dark:text-slate-600" />
        <div className="min-w-0 flex-1">
          <Link to={`/tasks/${task._id}`} className="block text-sm font-medium text-slate-900 hover:text-indigo-600 dark:text-slate-100 dark:hover:text-indigo-400">
            {task.title}
          </Link>
          <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1">
            <PriorityBadge priority={task.priority} />
            <DueLabel task={task} />
          </div>
        </div>
        {!overlay && (
          <div className="flex shrink-0 gap-0.5">
            <Link to={`/tasks/${task._id}/edit`} className="rounded p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200" aria-label="Edit task"><Pencil className="h-3.5 w-3.5" /></Link>
            <button onClick={() => onDelete(task)} className="rounded p-1 text-slate-400 hover:bg-slate-100 hover:text-red-600 dark:hover:bg-slate-800" aria-label="Delete task"><Trash2 className="h-3.5 w-3.5" /></button>
          </div>
        )}
      </div>
    </div>
  );
}

function SortableCard({ task, onDelete }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: task._id });
  return (
    <div
      ref={setNodeRef}
      style={{ transform: CSS.Transform.toString(transform), transition, opacity: isDragging ? 0.35 : 1 }}
      {...attributes}
      {...listeners}
    >
      <CardBody task={task} onDelete={onDelete} />
    </div>
  );
}

const dots = { Pending: 'bg-slate-400', 'In Progress': 'bg-indigo-500', Completed: 'bg-emerald-500' };

function Column({ status, tasks, onDelete }) {
  const navigate = useNavigate();
  const { setNodeRef, isOver } = useDroppable({ id: status });
  return (
    <div className={`flex min-h-[220px] flex-col rounded-xl p-3 transition-colors ${isOver ? 'bg-indigo-50 dark:bg-indigo-500/10' : 'bg-slate-100 dark:bg-slate-900/60'}`}>
      <div className="mb-3 flex items-center justify-between px-1">
        <div className="flex items-center gap-2">
          <span className={`h-2 w-2 rounded-full ${dots[status]}`} />
          <h3 className="text-sm font-semibold">{status}</h3>
          <span className="rounded-full bg-white px-2 py-0.5 text-xs font-medium text-slate-500 dark:bg-slate-800 dark:text-slate-400">{tasks.length}</span>
        </div>
        <button className="icon-btn !h-7 !w-7" aria-label={`Add task to ${status}`} onClick={() => navigate(`/tasks/new?status=${encodeURIComponent(status)}`)}>
          <Plus className="h-4 w-4" />
        </button>
      </div>
      <SortableContext items={tasks.map((t) => t._id)} strategy={verticalListSortingStrategy}>
        <div ref={setNodeRef} className="flex flex-1 flex-col gap-2.5">
          {tasks.map((t) => <SortableCard key={t._id} task={t} onDelete={onDelete} />)}
          {tasks.length === 0 && (
            <div className="flex flex-1 items-center justify-center rounded-lg border border-dashed border-slate-300 py-8 text-xs text-slate-400 dark:border-slate-700">
              Drop tasks here
            </div>
          )}
        </div>
      </SortableContext>
    </div>
  );
}

export default function KanbanBoard({ tasks, onReorder, onDelete }) {
  const [activeId, setActiveId] = useState(null);
  const sensors = useSensors(
    useSensor(MouseSensor, { activationConstraint: { distance: 6 } }),
    useSensor(TouchSensor, { activationConstraint: { delay: 200, tolerance: 8 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  const columns = Object.fromEntries(STATUSES.map((s) => [s, tasks.filter((t) => t.status === s).sort(byOrder)]));
  const active = tasks.find((t) => t._id === activeId);

  const handleDragEnd = ({ active: a, over }) => {
    setActiveId(null);
    if (!over) return;
    const task = tasks.find((t) => t._id === a.id);
    const overIsColumn = STATUSES.includes(over.id);
    const target = overIsColumn ? over.id : tasks.find((t) => t._id === over.id)?.status;
    if (!task || !target) return;

    const cols = Object.fromEntries(STATUSES.map((s) => [s, [...columns[s]]]));
    const fromIdx = cols[task.status].findIndex((t) => t._id === task._id);

    if (target === task.status) {
      const overIdx = overIsColumn ? cols[target].length - 1 : cols[target].findIndex((t) => t._id === over.id);
      if (overIdx === fromIdx || overIdx < 0) return;
      cols[target] = arrayMove(cols[target], fromIdx, overIdx);
    } else {
      cols[task.status].splice(fromIdx, 1);
      const overIdx = overIsColumn ? cols[target].length : cols[target].findIndex((t) => t._id === over.id);
      cols[target].splice(overIdx < 0 ? cols[target].length : overIdx, 0, { ...task, status: target });
    }

    onReorder(STATUSES.flatMap((s) => cols[s].map((t, i) => ({ ...t, status: s, order: i }))), task, target);
  };

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCorners}
      onDragStart={({ active: a }) => setActiveId(a.id)}
      onDragEnd={handleDragEnd}
      onDragCancel={() => setActiveId(null)}
    >
      <div className="grid gap-4 md:grid-cols-3">
        {STATUSES.map((s) => <Column key={s} status={s} tasks={columns[s]} onDelete={onDelete} />)}
      </div>
      <DragOverlay>{active ? <CardBody task={active} overlay /> : null}</DragOverlay>
    </DndContext>
  );
}
