import { useCallback, useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, Bell } from 'lucide-react';
import toast from 'react-hot-toast';
import { tasksApi } from '../services/api.js';
import useTasksChanged from '../hooks/useTasksChanged.js';
import { dueInfo } from '../utils/date.js';

export default function ReminderBell() {
  const [data, setData] = useState({ overdue: [], overdueCount: 0, dueSoon: [] });
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  const load = useCallback(() => {
    tasksApi
      .reminders()
      .then(({ data: d }) => {
        setData(d);
        // One gentle nudge per session
        if (d.overdueCount > 0 && !sessionStorage.getItem('overdueReminded')) {
          sessionStorage.setItem('overdueReminded', '1');
          toast(`You have ${d.overdueCount} overdue task${d.overdueCount > 1 ? 's' : ''}.`, {
            icon: <AlertTriangle className="h-4 w-4 text-amber-500" />,
          });
        }
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    load();
    const id = setInterval(load, 5 * 60 * 1000);
    return () => clearInterval(id);
  }, [load]);
  useTasksChanged(load);

  useEffect(() => {
    if (!open) return;
    const close = (e) => (!ref.current?.contains(e.target) || e.key === 'Escape') && setOpen(false);
    document.addEventListener('mousedown', close);
    document.addEventListener('keydown', close);
    return () => { document.removeEventListener('mousedown', close); document.removeEventListener('keydown', close); };
  }, [open]);

  const count = data.overdueCount + data.dueSoon.length;
  const items = [...data.overdue, ...data.dueSoon];

  return (
    <div className="relative" ref={ref}>
      <button className="icon-btn relative" onClick={() => setOpen((o) => !o)} aria-label={`Reminders${count ? `, ${count} pending` : ''}`} aria-expanded={open}>
        <Bell className="h-[18px] w-[18px]" />
        {count > 0 && (
          <span className={`absolute right-1 top-1 flex h-4 min-w-4 items-center justify-center rounded-full px-1 text-[10px] font-semibold text-white ${data.overdueCount ? 'bg-red-500' : 'bg-amber-500'}`}>
            {count > 9 ? '9+' : count}
          </span>
        )}
      </button>
      {open && (
        <div className="modal-enter card absolute right-0 z-40 mt-2 w-80 max-w-[calc(100vw-2rem)] shadow-lg">
          <div className="border-b border-slate-200 px-4 py-3 text-sm font-semibold dark:border-slate-800">Reminders</div>
          {items.length === 0 ? (
            <p className="px-4 py-8 text-center text-sm text-slate-500 dark:text-slate-400">Nothing due in the next 3 days.</p>
          ) : (
            <ul className="max-h-80 divide-y divide-slate-100 overflow-y-auto dark:divide-slate-800">
              {items.map((t) => {
                const info = dueInfo(t);
                return (
                  <li key={t._id}>
                    <Link to={`/tasks/${t._id}`} onClick={() => setOpen(false)} className="block px-4 py-3 hover:bg-slate-50 dark:hover:bg-slate-800/60">
                      <p className="truncate text-sm font-medium text-slate-900 dark:text-slate-100">{t.title}</p>
                      <p className={`mt-0.5 text-xs font-medium ${info.tone === 'overdue' ? 'text-red-600 dark:text-red-400' : 'text-amber-600 dark:text-amber-400'}`}>{info.label}</p>
                    </Link>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
