import { Link } from 'react-router-dom';
import { CheckCircle2, Circle, Pencil, Trash2 } from 'lucide-react';
import { StatusBadge, PriorityBadge, DueLabel, priorityBorder } from './Badges.jsx';
import Highlight from './Highlight.jsx';

export default function TaskCard({ task, onToggle, onDelete, query }) {
  const done = task.status === 'Completed';
  return (
    <div className={`card group flex items-start gap-3 border-l-[3px] p-4 transition-shadow hover:shadow-md dark:hover:shadow-none ${priorityBorder[task.priority]}`}>
      {onToggle && (
        <button
          onClick={() => onToggle(task)}
          className="mt-0.5 shrink-0 rounded-full text-slate-300 transition-colors hover:text-emerald-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 dark:text-slate-600"
          aria-label={done ? 'Mark as pending' : 'Mark as completed'}
          title={done ? 'Mark as pending' : 'Mark as completed'}
        >
          {done ? <CheckCircle2 className="h-5 w-5 text-emerald-500" /> : <Circle className="h-5 w-5" />}
        </button>
      )}
      <div className="min-w-0 flex-1">
        <Link
          to={`/tasks/${task._id}`}
          className={`block truncate font-medium hover:text-indigo-600 dark:hover:text-indigo-400 ${done ? 'text-slate-400 line-through dark:text-slate-500' : 'text-slate-900 dark:text-slate-100'}`}
        >
          <Highlight text={task.title} query={query} />
        </Link>
        {task.description && (
          <p className="mt-0.5 line-clamp-1 text-sm text-slate-500 dark:text-slate-400">
            <Highlight text={task.description} query={query} />
          </p>
        )}
        <div className="mt-2.5 flex flex-wrap items-center gap-x-3 gap-y-1.5">
          <StatusBadge status={task.status} />
          <PriorityBadge priority={task.priority} />
          <DueLabel task={task} />
        </div>
      </div>
      {onDelete && (
        <div className="flex shrink-0 gap-1 transition-opacity sm:opacity-0 sm:focus-within:opacity-100 sm:group-hover:opacity-100">
          <Link to={`/tasks/${task._id}/edit`} className="icon-btn" aria-label="Edit task" title="Edit"><Pencil className="h-4 w-4" /></Link>
          <button onClick={() => onDelete(task)} className="icon-btn hover:!text-red-600" aria-label="Delete task" title="Delete"><Trash2 className="h-4 w-4" /></button>
        </div>
      )}
    </div>
  );
}
