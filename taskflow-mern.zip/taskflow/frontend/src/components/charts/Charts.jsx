import { Bar, BarChart, CartesianGrid, Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { useTheme } from '../../context/ThemeContext.jsx';

const STATUS_COLORS = { Pending: '#94a3b8', 'In Progress': '#6366f1', Completed: '#10b981' };
const PRIORITY_COLORS = { Low: '#94a3b8', Medium: '#f59e0b', High: '#ef4444' };

function useChartTheme() {
  const dark = useTheme().theme === 'dark';
  return {
    tick: { fill: dark ? '#94a3b8' : '#64748b', fontSize: 12 },
    grid: dark ? '#1e293b' : '#e2e8f0',
    cursor: { fill: dark ? '#1e293b' : '#f1f5f9' },
    tooltip: {
      backgroundColor: dark ? '#0f172a' : '#ffffff',
      border: `1px solid ${dark ? '#334155' : '#e2e8f0'}`,
      borderRadius: 8,
      fontSize: 12,
      color: dark ? '#e2e8f0' : '#0f172a',
      boxShadow: 'none',
    },
  };
}

export function ChartCard({ title, subtitle, className = '', children }) {
  return (
    <div className={`card p-5 ${className}`}>
      <h3 className="text-sm font-semibold">{title}</h3>
      {subtitle && <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">{subtitle}</p>}
      <div className="mt-4">{children}</div>
    </div>
  );
}

export function CompletionRing({ percent, completed, total }) {
  const r = 52, c = 2 * Math.PI * r;
  return (
    <div className="flex flex-col items-center">
      <div className="relative h-36 w-36">
        <svg viewBox="0 0 120 120" className="h-full w-full -rotate-90">
          <circle cx="60" cy="60" r={r} fill="none" strokeWidth="10" className="stroke-slate-100 dark:stroke-slate-800" />
          <circle
            cx="60" cy="60" r={r} fill="none" strokeWidth="10" strokeLinecap="round"
            className="stroke-indigo-600 transition-[stroke-dashoffset] duration-700"
            strokeDasharray={c} strokeDashoffset={c * (1 - percent / 100)}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-3xl font-semibold text-slate-900 dark:text-slate-100">{percent}%</span>
          <span className="text-xs text-slate-500 dark:text-slate-400">complete</span>
        </div>
      </div>
      <p className="mt-3 text-sm text-slate-500 dark:text-slate-400">{completed} of {total} tasks done</p>
    </div>
  );
}

export function StatusDonut({ data }) {
  const t = useChartTheme();
  return (
    <div className="h-48">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie data={data} dataKey="count" nameKey="name" innerRadius="58%" outerRadius="85%" paddingAngle={2} stroke="none">
            {data.map((d) => <Cell key={d.name} fill={STATUS_COLORS[d.name]} />)}
          </Pie>
          <Tooltip contentStyle={t.tooltip} />
          <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12 }} />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}

export function PriorityBars({ data }) {
  const t = useChartTheme();
  return (
    <div className="h-48">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 4, right: 4, left: -24, bottom: 0 }}>
          <CartesianGrid vertical={false} stroke={t.grid} />
          <XAxis dataKey="name" tick={t.tick} axisLine={false} tickLine={false} />
          <YAxis allowDecimals={false} tick={t.tick} axisLine={false} tickLine={false} />
          <Tooltip contentStyle={t.tooltip} cursor={t.cursor} />
          <Bar dataKey="count" name="Tasks" radius={[6, 6, 0, 0]} maxBarSize={48}>
            {data.map((d) => <Cell key={d.name} fill={PRIORITY_COLORS[d.name]} />)}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function ActivityChart({ data }) {
  const t = useChartTheme();
  return (
    <div className="h-56">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 4, right: 4, left: -24, bottom: 0 }} barGap={4}>
          <CartesianGrid vertical={false} stroke={t.grid} />
          <XAxis dataKey="day" tick={t.tick} axisLine={false} tickLine={false} />
          <YAxis allowDecimals={false} tick={t.tick} axisLine={false} tickLine={false} />
          <Tooltip contentStyle={t.tooltip} cursor={t.cursor} />
          <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12 }} />
          <Bar dataKey="created" name="Created" fill="#6366f1" radius={[4, 4, 0, 0]} maxBarSize={20} />
          <Bar dataKey="completed" name="Completed" fill="#10b981" radius={[4, 4, 0, 0]} maxBarSize={20} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
