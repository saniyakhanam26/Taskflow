import { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { authApi } from '../services/api.js';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(() => !!localStorage.getItem('token'));

  // Restore session on refresh
  useEffect(() => {
    if (!localStorage.getItem('token')) return;
    authApi
      .me()
      .then((res) => setUser(res.data.user))
      .catch(() => localStorage.removeItem('token'))
      .finally(() => setLoading(false));
  }, []);

  // The axios interceptor fires this when the API says the token is invalid/expired
  useEffect(() => {
    const onLogout = () => { localStorage.removeItem('token'); setUser(null); };
    window.addEventListener('auth:logout', onLogout);
    return () => window.removeEventListener('auth:logout', onLogout);
  }, []);

  const persist = ({ token, user: u }) => {
    localStorage.setItem('token', token);
    setUser(u);
    return u;
  };

  const login = useCallback(async (creds) => persist((await authApi.login(creds)).data), []);
  const register = useCallback(async (data) => persist((await authApi.register(data)).data), []);
  const logout = useCallback(() => {
    localStorage.removeItem('token');
    sessionStorage.removeItem('overdueReminded');
    setUser(null);
  }, []);

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, setUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
