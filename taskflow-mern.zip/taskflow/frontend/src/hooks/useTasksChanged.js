import { useEffect, useRef } from 'react';

// Runs `callback` whenever any task is created, updated, deleted or reordered.
export default function useTasksChanged(callback) {
  const ref = useRef(callback);
  ref.current = callback;
  useEffect(() => {
    const handler = () => ref.current();
    window.addEventListener('tasks:changed', handler);
    return () => window.removeEventListener('tasks:changed', handler);
  }, []);
}
