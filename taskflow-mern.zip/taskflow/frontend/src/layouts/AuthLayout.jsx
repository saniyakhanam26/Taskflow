import { Outlet } from 'react-router-dom';
import { CheckSquare } from 'lucide-react';
import ThemeToggle from '../components/ThemeToggle.jsx';

const points = ['Kanban board with drag and drop', 'Due-date reminders and overdue alerts', 'Search, filters and sorting that stay in the URL'];

export default function AuthLayout() {
  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="hidden flex-col justify-between bg-slate-900 p-12 text-slate-300 lg:flex">
        <div className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-indigo-600 text-white"><CheckSquare className="h-5 w-5" /></span>
          <span className="text-xl font-semibold text-white">TaskFlow</span>
        </div>
        <div>
          <h2 className="max-w-md text-3xl font-semibold leading-tight text-white">Plan the week, finish what matters.</h2>
          <ul className="mt-8 space-y-3 text-sm">
            {points.map((p) => (
              <li key={p} className="flex items-center gap-3"><span className="h-1.5 w-1.5 rounded-full bg-indigo-400" />{p}</li>
            ))}
          </ul>
        </div>
        <p className="text-xs text-slate-500">Built with React, Node.js, Express and MongoDB.</p>
      </div>
      <div className="relative flex items-center justify-center px-6 py-12">
        <div className="absolute right-4 top-4"><ThemeToggle /></div>
        <div className="w-full max-w-sm"><Outlet /></div>
      </div>
    </div>
  );
}
