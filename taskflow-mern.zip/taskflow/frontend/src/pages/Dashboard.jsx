import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle2, ClipboardList, Clock, ListChecks, Loader, Plus } from 'lucide-react';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext.jsx';
import { getErrorMessage, tasksApi } from '../services/api.js';
import useTasksChanged from '../hooks/useTasksChanged.js';
import StatCard from '../components/StatCard.jsx';
import TaskCard from '../components/TaskCard.jsx';
import EmptyState from '../components/EmptyState.jsx';
import ErrorState from '../components/ErrorState.jsx';
import { DashboardSkeleton } from '../components/Skeleton.jsx';
import { ActivityChart, ChartCard, CompletionRing, PriorityBars, StatusDonut } from '../components/charts/Charts.jsx';
import { dueInfo } from '../utils/date.js';

const greeting = () => {
  const h = new Date().getHours();
  return h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
};

export default function Dashboard() {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [error, setError] = useState(null);

  const load = useCallback(() => {
    return tasksApi
      .stats()
      .then(({ data }) => { setStats(data.stats); setError(null); })
      .catch((e) => setError(getErrorMessage(e)));
  }, []);

  useEffect(() => { load(); }, [load]);
  useTasksChanged(load);

  const toggle = async (task) => {
    try {
      await tasksApi.update(task._id, { status: task.status === 'Completed' ? 'Pending' : 'Completed' });
      toast.success(task.status === 'Completed' ? 'Marked as pending' : 'Task completed');
    } catch (e) {
      toast.error(getErrorMessage(e));
    }
  };

  if (error && !stats) return <ErrorState message={error} onRetry={load} />;
  if (!stats) return <DashboardSkeleton />;

  const upcoming = [...stats.reminders.overdue, ...stats.reminders.dueSoon].slice(0, 6);
  const date = new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' });

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">{greeting()}, {user.name.split(' ')[0]}</h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">{date}</p>
        </div>
        <Link to="/tasks/new" className="btn-primary"><Plus className="h-4 w-4" />Add task</Link>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard icon={ListChecks} label="Total tasks" value={stats.total} />
        <StatCard icon={Clock} label="Pending" value={stats.pending} tone="amber" />
        <StatCard icon={Loader} label="In progress" value={stats.inProgress} tone="indigo" />
        <StatCard icon={CheckCircle2} label="Completed" value={stats.completed} tone="emerald" />
      </div>

      {stats.total === 0 ? (
        <EmptyState
          icon={ClipboardList}
          title="No tasks yet"
          description="Create your first task and your progress, charts and reminders will show up here."
          action={<Link to="/tasks/new" className="btn-primary"><Plus className="h-4 w-4" />Create a task</Link>}
        />
      ) : (
        <>
          <div className="grid gap-4 lg:grid-cols-3">
            <ChartCard title="Completion" subtitle="Share of all tasks marked completed">
              <CompletionRing percent={stats.completionRate} completed={stats.completed} total={stats.total} />
            </ChartCard>
            <ChartCard title="Status" subtitle="Where your tasks stand"><StatusDonut data={stats.byStatus} /></ChartCard>
            <ChartCard title="Priority" subtitle="Tasks by priority level"><PriorityBars data={stats.byPriority} /></ChartCard>
          </div>

          <div className="grid gap-4 lg:grid-cols-3">
            <ChartCard title="Last 7 days" subtitle="Tasks created and completed per day" className="lg:col-span-2">
              <ActivityChart data={stats.activity} />
            </ChartCard>
            <div className="card p-5">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold">Due soon</h3>
                {stats.reminders.overdueCount > 0 && (
                  <span className="rounded-full bg-red-50 px-2 py-0.5 text-xs font-medium text-red-600 dark:bg-red-500/10 dark:text-red-400">{stats.reminders.overdueCount} overdue</span>
                )}
              </div>
              {upcoming.length === 0 ? (
                <p className="mt-6 text-sm text-slate-500 dark:text-slate-400">You’re all caught up. Nothing is due in the next 3 days.</p>
              ) : (
                <ul className="mt-3 divide-y divide-slate-100 dark:divide-slate-800">
                  {upcoming.map((t) => {
                    const info = dueInfo(t);
                    return (
                      <li key={t._id}>
                        <Link to={`/tasks/${t._id}`} className="-mx-2 block rounded-lg px-2 py-2.5 hover:bg-slate-50 dark:hover:bg-slate-800/60">
                          <p className="truncate text-sm font-medium text-slate-900 dark:text-slate-100">{t.title}</p>
                          <p className={`text-xs font-medium ${info.tone === 'overdue' ? 'text-red-600 dark:text-red-400' : 'text-amber-600 dark:text-amber-400'}`}>{info.label}</p>
                        </Link>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          </div>

          <section>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-base font-semibold">Recent tasks</h2>
              <Link to="/tasks" className="text-sm font-medium text-indigo-600 hover:underline dark:text-indigo-400">View all</Link>
            </div>
            <div className="space-y-3">
              {stats.recent.map((t) => <TaskCard key={t._id} task={t} onToggle={toggle} />)}
            </div>
          </section>
        </>
      )}
    </div>
  );
}
