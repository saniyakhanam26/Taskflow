import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Moon, Sun } from 'lucide-react';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext.jsx';
import { useTheme } from '../context/ThemeContext.jsx';
import { getErrorMessage, usersApi } from '../services/api.js';
import { Field, PasswordInput } from '../components/Field.jsx';
import ConfirmModal from '../components/ConfirmModal.jsx';

const EMAIL_RE = /^\S+@\S+\.\S+$/;

function Section({ title, description, children }) {
  return (
    <section className="card p-6">
      <h2 className="text-base font-semibold">{title}</h2>
      {description && <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">{description}</p>}
      <div className="mt-5">{children}</div>
    </section>
  );
}

export default function Profile() {
  const { user, setUser, logout } = useAuth();
  const { theme, setTheme } = useTheme();
  const navigate = useNavigate();

  const [info, setInfo] = useState({ name: user.name, email: user.email });
  const [infoErr, setInfoErr] = useState({});
  const [savingInfo, setSavingInfo] = useState(false);

  const [pw, setPw] = useState({ currentPassword: '', newPassword: '', confirm: '' });
  const [pwErr, setPwErr] = useState({});
  const [savingPw, setSavingPw] = useState(false);

  const [delOpen, setDelOpen] = useState(false);
  const [delPw, setDelPw] = useState('');
  const [deleting, setDeleting] = useState(false);

  const saveInfo = async (e) => {
    e.preventDefault();
    const errs = {};
    if (!info.name.trim()) errs.name = 'Name can’t be empty.';
    if (!EMAIL_RE.test(info.email)) errs.email = 'Enter a valid email address.';
    setInfoErr(errs);
    if (Object.keys(errs).length) return;
    setSavingInfo(true);
    try {
      const { data } = await usersApi.updateProfile(info);
      setUser(data.user);
      toast.success('Profile updated');
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSavingInfo(false);
    }
  };

  const savePassword = async (e) => {
    e.preventDefault();
    const errs = {};
    if (!pw.currentPassword) errs.currentPassword = 'Enter your current password.';
    if (pw.newPassword.length < 8) errs.newPassword = 'Use at least 8 characters.';
    if (pw.confirm !== pw.newPassword) errs.confirm = 'Passwords do not match.';
    setPwErr(errs);
    if (Object.keys(errs).length) return;
    setSavingPw(true);
    try {
      await usersApi.changePassword({ currentPassword: pw.currentPassword, newPassword: pw.newPassword });
      toast.success('Password updated');
      setPw({ currentPassword: '', newPassword: '', confirm: '' });
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSavingPw(false);
    }
  };

  const deleteAccount = async () => {
    if (!delPw) return toast.error('Enter your password to confirm.');
    setDeleting(true);
    try {
      await usersApi.deleteAccount(delPw);
      toast.success('Account deleted');
      logout();
      navigate('/register', { replace: true });
    } catch (err) {
      toast.error(getErrorMessage(err));
      setDeleting(false);
    }
  };

  const memberSince = new Date(user.createdAt).toLocaleDateString(undefined, { month: 'long', year: 'numeric' });

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Profile settings</h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Member since {memberSince}</p>
      </div>

      <Section title="Personal information" description="Update your name and the email you sign in with.">
        <form onSubmit={saveInfo} noValidate className="space-y-4">
          <Field label="Full name" htmlFor="p-name" error={infoErr.name}>
            <input id="p-name" className={`input ${infoErr.name ? 'input-error' : ''}`} value={info.name} onChange={(e) => setInfo({ ...info, name: e.target.value })} />
          </Field>
          <Field label="Email" htmlFor="p-email" error={infoErr.email}>
            <input id="p-email" type="email" className={`input ${infoErr.email ? 'input-error' : ''}`} value={info.email} onChange={(e) => setInfo({ ...info, email: e.target.value })} />
          </Field>
          <div className="flex justify-end">
            <button className="btn-primary" disabled={savingInfo || (info.name === user.name && info.email === user.email)}>{savingInfo ? 'Saving…' : 'Save changes'}</button>
          </div>
        </form>
      </Section>

      <Section title="Appearance" description="Choose how TaskFlow looks on this device.">
        <div className="grid grid-cols-2 gap-3">
          {[['light', Sun, 'Light'], ['dark', Moon, 'Dark']].map(([v, Icon, label]) => (
            <button
              key={v}
              onClick={() => setTheme(v)}
              aria-pressed={theme === v}
              className={`flex items-center justify-center gap-2 rounded-lg border px-4 py-3 text-sm font-medium transition-colors ${
                theme === v ? 'border-indigo-500 bg-indigo-50 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-300' : 'border-slate-300 hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="h-4 w-4" />{label}
            </button>
          ))}
        </div>
      </Section>

      <Section title="Password" description="Use a strong password you don’t use elsewhere.">
        <form onSubmit={savePassword} noValidate className="space-y-4">
          <Field label="Current password" htmlFor="cp" error={pwErr.currentPassword}>
            <PasswordInput id="cp" autoComplete="current-password" error={pwErr.currentPassword} value={pw.currentPassword} onChange={(e) => setPw({ ...pw, currentPassword: e.target.value })} />
          </Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="New password" htmlFor="np" error={pwErr.newPassword}>
              <PasswordInput id="np" autoComplete="new-password" error={pwErr.newPassword} value={pw.newPassword} onChange={(e) => setPw({ ...pw, newPassword: e.target.value })} />
            </Field>
            <Field label="Confirm new password" htmlFor="cnp" error={pwErr.confirm}>
              <PasswordInput id="cnp" autoComplete="new-password" error={pwErr.confirm} value={pw.confirm} onChange={(e) => setPw({ ...pw, confirm: e.target.value })} />
            </Field>
          </div>
          <div className="flex justify-end"><button className="btn-primary" disabled={savingPw}>{savingPw ? 'Updating…' : 'Update password'}</button></div>
        </form>
      </Section>

      <section className="card border-red-200 p-6 dark:border-red-500/30">
        <h2 className="text-base font-semibold">Delete account</h2>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Permanently remove your account and every task in it.</p>
        <button className="btn-danger mt-4" onClick={() => setDelOpen(true)}>Delete account</button>
      </section>

      <ConfirmModal
        open={delOpen}
        title="Delete your account?"
        message="All of your tasks will be permanently deleted. Enter your password to confirm."
        confirmLabel="Delete account"
        loading={deleting}
        onConfirm={deleteAccount}
        onCancel={() => { setDelOpen(false); setDelPw(''); }}
      >
        <PasswordInput id="del-pw" autoComplete="current-password" value={delPw} onChange={(e) => setDelPw(e.target.value)} placeholder="Your password" />
      </ConfirmModal>
    </div>
  );
}
