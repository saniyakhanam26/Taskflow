import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, CheckCircle2, Pencil, Trash2 } from 'lucide-react';
import toast from 'react-hot-toast';
import { getErrorMessage, tasksApi } from '../services/api.js';
import { formatDateTime, formatDue } from '../utils/date.js';
import { DueLabel, PriorityBadge, STATUSES, StatusBadge } from '../components/Badges.jsx';
import ConfirmModal from '../components/ConfirmModal.jsx';
import ErrorState from '../components/ErrorState.jsx';
import { Skeleton } from '../components/Skeleton.jsx';

function Meta({ label, children }) {
  return (
    <div>
      <dt className="text-xs text-slate-500 dark:text-slate-400">{label}</dt>
      <dd className="mt-1 text-sm font-medium text-slate-900 dark:text-slate-100">{children}</dd>
    </div>
  );
}

export default function TaskDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [task, setTask] = useState(null);
  const [error, setError] = useState(null);
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    tasksApi.get(id).then(({ data }) => setTask(data.task)).catch((e) => setError(getErrorMessage(e)));
  }, [id]);

  const setStatus = async (status) => {
    try {
      const { data } = await tasksApi.update(id, { status });
      setTask(data.task);
      toast.success(`Status changed to ${status}`);
    } catch (e) {
      toast.error(getErrorMessage(e));
    }
  };

  const remove = async () => {
    setBusy(true);
    try {
      await tasksApi.remove(id);
      toast.success('Task deleted');
      navigate('/tasks', { replace: true });
    } catch (e) {
      toast.error(getErrorMessage(e));
      setBusy(false);
    }
  };

  if (error) return <ErrorState message={error} onRetry={() => navigate('/tasks')} />;
  if (!task) {
    return (
      <div className="mx-auto max-w-3xl space-y-4">
        <Skeleton className="h-4 w-16" /><Skeleton className="h-8 w-2/3" /><Skeleton className="h-64 rounded-xl" />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl">
      <Link to="/tasks" className="inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100">
        <ArrowLeft className="h-4 w-4" />My tasks
      </Link>

      <div className="mt-3 flex flex-wrap items-start justify-between gap-3">
        <h1 className="min-w-0 break-words text-2xl font-semibold tracking-tight">{task.title}</h1>
        <div className="flex gap-2">
          {task.status !== 'Completed' && (
            <button className="btn-secondary" onClick={() => setStatus('Completed')}><CheckCircle2 className="h-4 w-4" />Mark completed</button>
          )}
          <Link to={`/tasks/${id}/edit`} className="btn-secondary"><Pencil className="h-4 w-4" />Edit</Link>
          <button className="btn-secondary hover:!text-red-600" onClick={() => setConfirm(true)} aria-label="Delete task"><Trash2 className="h-4 w-4" /></button>
        </div>
      </div>

      <div className="card mt-6 divide-y divide-slate-200 dark:divide-slate-800">
        <div className="p-6">
          <h2 className="text-sm font-semibold">Description</h2>
          <p className="mt-2 whitespace-pre-wrap break-words text-sm leading-relaxed text-slate-600 dark:text-slate-300">
            {task.description || <span className="text-slate-400">No description added.</span>}
          </p>
        </div>
        <dl className="grid grid-cols-2 gap-6 p-6 sm:grid-cols-3">
          <Meta label="Status">
            <select className="input !w-auto !py-1" aria-label="Change status" value={task.status} onChange={(e) => setStatus(e.target.value)}>
              {STATUSES.map((s) => <option key={s}>{s}</option>)}
            </select>
          </Meta>
          <Meta label="Priority"><PriorityBadge priority={task.priority} /></Meta>
          <Meta label="Due date">
            {task.dueDate ? <span className="flex flex-col gap-0.5"><span>{formatDue(task.dueDate)}</span><DueLabel task={task} /></span> : 'Not set'}
          </Meta>
          <Meta label="Current status"><StatusBadge status={task.status} /></Meta>
          <Meta label="Created">{formatDateTime(task.createdAt)}</Meta>
          <Meta label="Last updated">{formatDateTime(task.updatedAt)}</Meta>
          {task.completedAt && <Meta label="Completed">{formatDateTime(task.completedAt)}</Meta>}
        </dl>
      </div>

      <ConfirmModal
        open={confirm}
        title="Delete this task?"
        message={`“${task.title}” will be permanently deleted. This can’t be undone.`}
        confirmLabel="Delete task"
        loading={busy}
        onConfirm={remove}
        onCancel={() => setConfirm(false)}
      />
    </div>
  );
}
