import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { ArrowLeft, Flag } from 'lucide-react';
import toast from 'react-hot-toast';
import { getErrorMessage, tasksApi } from '../services/api.js';
import { toInputDate } from '../utils/date.js';
import { Field } from '../components/Field.jsx';
import ErrorState from '../components/ErrorState.jsx';
import { Skeleton } from '../components/Skeleton.jsx';
import { PRIORITIES, STATUSES, priorityText } from '../components/Badges.jsx';

export default function TaskFormPage() {
  const { id } = useParams();
  const editing = !!id;
  const navigate = useNavigate();
  const [sp] = useSearchParams();
  const initialStatus = STATUSES.includes(sp.get('status')) ? sp.get('status') : 'Pending';

  const [form, setForm] = useState({ title: '', description: '', status: initialStatus, priority: 'Medium', dueDate: '' });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(editing);
  const [loadError, setLoadError] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!editing) return;
    tasksApi
      .get(id)
      .then(({ data }) => {
        const t = data.task;
        setForm({ title: t.title, description: t.description || '', status: t.status, priority: t.priority, dueDate: toInputDate(t.dueDate) });
      })
      .catch((e) => setLoadError(getErrorMessage(e)))
      .finally(() => setLoading(false));
  }, [id, editing]);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    const errs = {};
    if (!form.title.trim()) errs.title = 'Give your task a title.';
    else if (form.title.length > 120) errs.title = 'Title must be 120 characters or fewer.';
    if (form.description.length > 2000) errs.description = 'Description must be 2000 characters or fewer.';
    setErrors(errs);
    if (Object.keys(errs).length) return;

    setSaving(true);
    try {
      const payload = { ...form, dueDate: form.dueDate || null };
      if (editing) {
        await tasksApi.update(id, payload);
        toast.success('Task updated');
        navigate(`/tasks/${id}`);
      } else {
        await tasksApi.create(payload);
        toast.success('Task created');
        navigate('/tasks');
      }
    } catch (err) {
      toast.error(getErrorMessage(err));
      setSaving(false);
    }
  };

  if (loadError) return <ErrorState message={loadError} />;

  return (
    <div className="mx-auto max-w-2xl">
      <Link to={editing ? `/tasks/${id}` : '/tasks'} className="inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100">
        <ArrowLeft className="h-4 w-4" />Back
      </Link>
      <h1 className="mt-3 text-2xl font-semibold tracking-tight">{editing ? 'Edit task' : 'New task'}</h1>

      {loading ? (
        <div className="card mt-6 space-y-5 p-6">
          <Skeleton className="h-10" /><Skeleton className="h-28" /><Skeleton className="h-10" />
        </div>
      ) : (
        <form onSubmit={submit} noValidate className="card mt-6 space-y-5 p-6">
          <Field label="Title" htmlFor="title" error={errors.title}>
            <input id="title" autoFocus className={`input ${errors.title ? 'input-error' : ''}`} value={form.title} onChange={set('title')} placeholder="What needs to be done?" maxLength={140} />
          </Field>
          <Field label="Description" htmlFor="description" error={errors.description} hint={`${form.description.length}/2000`}>
            <textarea id="description" rows={5} className={`input resize-y ${errors.description ? 'input-error' : ''}`} value={form.description} onChange={set('description')} placeholder="Add details, links or notes (optional)" />
          </Field>

          <div className="grid gap-5 sm:grid-cols-2">
            <Field label="Status" htmlFor="status">
              <select id="status" className="input" value={form.status} onChange={set('status')}>
                {STATUSES.map((s) => <option key={s}>{s}</option>)}
              </select>
            </Field>
            <Field label="Due date" htmlFor="dueDate">
              <input id="dueDate" type="date" className="input" value={form.dueDate} onChange={set('dueDate')} />
            </Field>
          </div>

          <div>
            <span className="label">Priority</span>
            <div className="grid grid-cols-3 gap-2" role="radiogroup" aria-label="Priority">
              {PRIORITIES.map((p) => (
                <button
                  type="button"
                  key={p}
                  role="radio"
                  aria-checked={form.priority === p}
                  onClick={() => setForm((f) => ({ ...f, priority: p }))}
                  className={`flex items-center justify-center gap-1.5 rounded-lg border px-3 py-2 text-sm font-medium transition-colors ${
                    form.priority === p
                      ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-500/10'
                      : 'border-slate-300 hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800'
                  } ${priorityText[p]}`}
                >
                  <Flag className="h-4 w-4" />{p}
                </button>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-2 border-t border-slate-200 pt-5 dark:border-slate-800">
            <Link to={editing ? `/tasks/${id}` : '/tasks'} className="btn-secondary">Cancel</Link>
            <button className="btn-primary" disabled={saving}>{saving ? 'Saving…' : editing ? 'Save changes' : 'Create task'}</button>
          </div>
        </form>
      )}
    </div>
  );
}
