import { useCallback, useEffect, useRef, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ClipboardList, LayoutGrid, List, Plus, Search, SearchX, X } from 'lucide-react';
import toast from 'react-hot-toast';
import { getErrorMessage, tasksApi } from '../services/api.js';
import useDebounce from '../hooks/useDebounce.js';
import TaskCard from '../components/TaskCard.jsx';
import KanbanBoard from '../components/KanbanBoard.jsx';
import Pagination from '../components/Pagination.jsx';
import ConfirmModal from '../components/ConfirmModal.jsx';
import EmptyState from '../components/EmptyState.jsx';
import ErrorState from '../components/ErrorState.jsx';
import { BoardSkeleton, TaskListSkeleton } from '../components/Skeleton.jsx';
import { PRIORITIES, STATUSES } from '../components/Badges.jsx';

const LIMIT = 8;
const SORTS = [
  ['createdAt:desc', 'Newest first'],
  ['createdAt:asc', 'Oldest first'],
  ['dueDate:asc', 'Due date (soonest)'],
  ['dueDate:desc', 'Due date (latest)'],
  ['updatedAt:desc', 'Recently updated'],
  ['title:asc', 'Title A–Z'],
];
const DUE = [['overdue', 'Overdue'], ['today', 'Due today'], ['week', 'Next 7 days'], ['none', 'No due date']];

export default function Tasks() {
  const [params, setParams] = useSearchParams();
  const [view, setView] = useState(() => localStorage.getItem('taskView') || 'list');
  const q = params.get('q') || '';
  const status = params.get('status') || '';
  const priority = params.get('priority') || '';
  const due = params.get('due') || '';
  const sort = params.get('sort') || 'createdAt:desc';
  const page = Math.max(parseInt(params.get('page'), 10) || 1, 1);
  const board = view === 'board';

  const [search, setSearch] = useState(q);
  const debounced = useDebounce(search);
  const [tasks, setTasks] = useState([]);
  const [pagination, setPagination] = useState({ page: 1, pages: 1, total: 0, limit: LIMIT });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [toDelete, setToDelete] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const reqId = useRef(0);

  const update = useCallback(
    (changes) => {
      const next = new URLSearchParams(params);
      Object.entries(changes).forEach(([k, v]) => (v ? next.set(k, v) : next.delete(k)));
      if (!('page' in changes)) next.delete('page');
      setParams(next, { replace: true });
    },
    [params, setParams]
  );

  // Push the debounced search text into the URL
  useEffect(() => {
    if (debounced !== q) update({ q: debounced });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debounced]);

  const fetchTasks = useCallback(async () => {
    const id = ++reqId.current;
    const query = board
      ? { search: q || undefined, priority: priority || undefined, due: due || undefined, sort: 'order:asc', limit: 200 }
      : { search: q || undefined, status: status || undefined, priority: priority || undefined, due: due || undefined, sort, page, limit: LIMIT };
    try {
      const { data } = await tasksApi.list(query);
      if (id !== reqId.current) return;
      setTasks(data.tasks);
      setPagination(data.pagination);
      setError(null);
    } catch (e) {
      if (id === reqId.current) setError(getErrorMessage(e));
    }
  }, [board, q, status, priority, due, sort, page]);

  useEffect(() => {
    setLoading(true);
    fetchTasks().finally(() => setLoading(false));
  }, [fetchTasks]);

  const changeView = (v) => {
    setView(v);
    localStorage.setItem('taskView', v);
  };

  const hasFilters = !!(q || status || priority || due);
  const clearFilters = () => {
    setSearch('');
    setParams(new URLSearchParams(), { replace: true });
  };

  const toggle = async (task) => {
    try {
      await tasksApi.update(task._id, { status: task.status === 'Completed' ? 'Pending' : 'Completed' });
      toast.success(task.status === 'Completed' ? 'Marked as pending' : 'Task completed');
      fetchTasks();
    } catch (e) {
      toast.error(getErrorMessage(e));
    }
  };

  const confirmDelete = async () => {
    setDeleting(true);
    try {
      await tasksApi.remove(toDelete._id);
      toast.success('Task deleted');
      setToDelete(null);
      if (!board && tasks.length === 1 && page > 1) update({ page: String(page - 1) });
      else fetchTasks();
    } catch (e) {
      toast.error(getErrorMessage(e));
    } finally {
      setDeleting(false);
    }
  };

  const reorder = async (next, task, target) => {
    const prev = tasks;
    setTasks(next);
    try {
      await tasksApi.reorder(next.map((t) => ({ id: t._id, status: t.status, order: t.order })));
      if (target !== task.status) toast.success(`Moved to ${target}`);
    } catch (e) {
      setTasks(prev);
      toast.error(getErrorMessage(e));
    }
  };

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">My tasks</h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            {loading ? 'Loading…' : `${pagination.total} ${pagination.total === 1 ? 'task' : 'tasks'}${hasFilters ? ' match your filters' : ''}`}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="inline-flex rounded-lg border border-slate-300 bg-white p-0.5 dark:border-slate-700 dark:bg-slate-900" role="group" aria-label="View">
            {[['list', List, 'List'], ['board', LayoutGrid, 'Board']].map(([v, Icon, label]) => (
              <button
                key={v}
                onClick={() => changeView(v)}
                aria-pressed={view === v}
                className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${
                  view === v ? 'bg-slate-100 text-slate-900 dark:bg-slate-800 dark:text-slate-100' : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-100'
                }`}
              >
                <Icon className="h-4 w-4" />{label}
              </button>
            ))}
          </div>
          <Link to="/tasks/new" className="btn-primary sm:hidden"><Plus className="h-4 w-4" />New</Link>
        </div>
      </div>

      {/* Search + filters */}
      <div className="mt-5 space-y-3">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            className="input pl-9 pr-9"
            placeholder="Search by title or description"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            aria-label="Search tasks"
          />
          {search && (
            <button className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200" onClick={() => setSearch('')} aria-label="Clear search">
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
        <div className="grid grid-cols-2 gap-3 md:flex md:flex-wrap md:items-center">
          {!board && (
            <select className="input md:w-40" aria-label="Filter by status" value={status} onChange={(e) => update({ status: e.target.value })}>
              <option value="">All statuses</option>
              {STATUSES.map((s) => <option key={s}>{s}</option>)}
            </select>
          )}
          <select className="input md:w-40" aria-label="Filter by priority" value={priority} onChange={(e) => update({ priority: e.target.value })}>
            <option value="">All priorities</option>
            {PRIORITIES.map((p) => <option key={p}>{p}</option>)}
          </select>
          <select className="input md:w-40" aria-label="Filter by due date" value={due} onChange={(e) => update({ due: e.target.value })}>
            <option value="">Any due date</option>
            {DUE.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </select>
          {!board && (
            <select className="input md:w-48" aria-label="Sort tasks" value={sort} onChange={(e) => update({ sort: e.target.value === 'createdAt:desc' ? '' : e.target.value })}>
              {SORTS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </select>
          )}
          {hasFilters && <button className="btn-ghost col-span-2 md:col-span-1" onClick={clearFilters}><X className="h-4 w-4" />Clear filters</button>}
        </div>
      </div>

      <div className="mt-6">
        {error && !tasks.length ? (
          <ErrorState message={error} onRetry={fetchTasks} />
        ) : loading ? (
          board ? <BoardSkeleton /> : <TaskListSkeleton />
        ) : tasks.length === 0 && !board ? (
          hasFilters ? (
            <EmptyState icon={SearchX} title="No matching tasks" description="Try a different keyword or remove some filters." action={<button className="btn-secondary" onClick={clearFilters}>Clear filters</button>} />
          ) : (
            <EmptyState icon={ClipboardList} title="No tasks yet" description="Add your first task to start tracking your work." action={<Link to="/tasks/new" className="btn-primary"><Plus className="h-4 w-4" />Create a task</Link>} />
          )
        ) : board ? (
          <>
            <KanbanBoard tasks={tasks} onReorder={reorder} onDelete={setToDelete} />
            <p className="mt-4 text-xs text-slate-500 dark:text-slate-400">Drag cards between columns to change their status, or within a column to reorder.</p>
          </>
        ) : (
          <>
            <div className="space-y-3">
              {tasks.map((t) => <TaskCard key={t._id} task={t} query={q} onToggle={toggle} onDelete={setToDelete} />)}
            </div>
            <Pagination page={pagination.page} pages={pagination.pages} total={pagination.total} limit={pagination.limit} onPage={(p) => update({ page: String(p) })} />
          </>
        )}
      </div>

      <ConfirmModal
        open={!!toDelete}
        title="Delete this task?"
        message={toDelete ? `“${toDelete.title}” will be permanently deleted. This can’t be undone.` : ''}
        confirmLabel="Delete task"
        loading={deleting}
        onConfirm={confirmDelete}
        onCancel={() => setToDelete(null)}
      />
    </div>
  );
}
