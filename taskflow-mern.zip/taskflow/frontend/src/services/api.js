import axios from 'axios';

const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || '/api', timeout: 15000 });

export const localDate = (d = new Date()) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  // Task queries need the user's local "today" and timezone for due dates and charts
  if (config.method === 'get' && config.url?.startsWith('/tasks')) {
    config.params = {
      today: localDate(),
      tz: Intl.DateTimeFormat().resolvedOptions().timeZone,
      ...config.params,
    };
  }
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (err) => {
    const url = err.config?.url || '';
    const isAuthForm = url.includes('/auth/login') || url.includes('/auth/register');
    if (err.response?.status === 401 && !isAuthForm) window.dispatchEvent(new Event('auth:logout'));
    return Promise.reject(err);
  }
);

export function getErrorMessage(err) {
  if (err.response?.data?.message) return err.response.data.message;
  if (err.code === 'ECONNABORTED') return 'The request timed out. Please try again.';
  if (err.request) return 'Cannot reach the server. Check your connection and try again.';
  return 'Something went wrong. Please try again.';
}

// Components listen for this to refresh counts, reminders and lists
const changed = (res) => {
  window.dispatchEvent(new Event('tasks:changed'));
  return res;
};

export const authApi = {
  register: (data) => api.post('/auth/register', data),
  login: (data) => api.post('/auth/login', data),
  me: () => api.get('/auth/me'),
};

export const tasksApi = {
  list: (params) => api.get('/tasks', { params }),
  stats: () => api.get('/tasks/stats'),
  reminders: () => api.get('/tasks/reminders'),
  get: (id) => api.get(`/tasks/${id}`),
  create: (data) => api.post('/tasks', data).then(changed),
  update: (id, data) => api.put(`/tasks/${id}`, data).then(changed),
  remove: (id) => api.delete(`/tasks/${id}`).then(changed),
  reorder: (items) => api.patch('/tasks/reorder', { items }).then(changed),
};

export const usersApi = {
  updateProfile: (data) => api.put('/users/profile', data),
  changePassword: (data) => api.put('/users/password', data),
  deleteAccount: (password) => api.delete('/users/me', { data: { password } }),
};

export default api;
