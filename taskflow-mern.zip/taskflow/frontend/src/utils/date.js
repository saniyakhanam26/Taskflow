import { localDate } from '../services/api.js';

const DAY = 864e5;

// Due dates are date-only values stored at UTC midnight, so format them in UTC.
export const formatDue = (iso) =>
  iso ? new Date(iso).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric', timeZone: 'UTC' }) : '—';

export const formatDateTime = (iso) =>
  iso ? new Date(iso).toLocaleString(undefined, { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' }) : '—';

export const toInputDate = (iso) => (iso ? new Date(iso).toISOString().slice(0, 10) : '');

// { label, tone: 'overdue' | 'soon' | 'normal' } or null when there is no due date
export function dueInfo(task) {
  if (!task.dueDate) return null;
  const due = task.dueDate.slice(0, 10);
  if (task.status === 'Completed') return { label: formatDue(task.dueDate), tone: 'normal' };
  const diff = Math.round((Date.parse(due) - Date.parse(localDate())) / DAY);
  if (diff < 0) return { label: `Overdue by ${-diff} day${diff === -1 ? '' : 's'}`, tone: 'overdue' };
  if (diff === 0) return { label: 'Due today', tone: 'soon' };
  if (diff === 1) return { label: 'Due tomorrow', tone: 'soon' };
  if (diff <= 3) return { label: `Due in ${diff} days`, tone: 'soon' };
  return { label: formatDue(task.dueDate), tone: 'normal' };
}
